# Image Sharpening using Knowledge Distillation

## Problem Statement
Enhance image sharpness during video conferencing using a teacher-student knowledge distillation model.

## Dataset
Synthetic downsampled images using bicubic/bilinear from high-res.

## Requirements
- Python
- PyTorch
- OpenCV
- skimage

## Evaluation
- SSIM > 90%
- MOS (optional subjective test)
