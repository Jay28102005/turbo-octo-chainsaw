# Entry point for training and evaluation
from models.teacher_model import TeacherModel
from models.student_model import StudentModel
# Add training loop here
