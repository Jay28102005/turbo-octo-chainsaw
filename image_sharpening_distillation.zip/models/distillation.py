import torch.nn.functional as F

def distillation_loss(student_out, teacher_out, ground_truth, alpha=0.5):
    loss_student = F.mse_loss(student_out, ground_truth)
    loss_distill = F.mse_loss(student_out, teacher_out)
    return alpha * loss_student + (1 - alpha) * loss_distill
