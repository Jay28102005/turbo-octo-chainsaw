from skimage.metrics import structural_similarity as ssim
import numpy as np

def calculate_ssim(img1, img2):
    return ssim(img1, img2, multichannel=True, data_range=img2.max() - img2.min())
